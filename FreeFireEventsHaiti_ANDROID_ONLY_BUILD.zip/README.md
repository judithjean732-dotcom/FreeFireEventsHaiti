# Free Fire Events Haiti — Android starter project

Premye vèsyon pwojè Android la. Li sèvi ak yon WebView lokal pou montre paj nouvèl ofisyèl Garena ak gid sipò sou evènman yo.

## Louvri pwojè a
1. Enstale Android Studio.
2. Chwazi **Open** epi chwazi katab `FreeFireEventsHaiti`.
3. Kite Gradle senkronize.
4. Ale nan **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

APK a ap parèt nòmalman nan `app/build/outputs/apk/debug/app-debug.apk`.

## Limit vèsyon sa a
Garena pa bay yon API piblik dokimante pou yon kalandriye evènman an tan reyèl separe pou sèvè Amerik di Nò ak Free Fire MAX. Vèsyon sa a louvri nouvèl ofisyèl Garena; dat ak rekonpans yo dwe verifye nan onglet Events anndan jwèt la. Li poko gen push notifications oswa klasman evènman otomatik.
